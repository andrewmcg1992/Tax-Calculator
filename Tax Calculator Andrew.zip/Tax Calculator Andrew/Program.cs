﻿using System;

namespace Tax_Calculator_Andrew
{
    class Program
    {
        static void Main(string[] args)
        {
//This section creates the Gross Income double by using Readline Parse.
            Console.WriteLine("Please enter Gross Income: ");
            double grossIncome = double.Parse(Console.ReadLine());

            double grossIncomeTax = 0;


            //This code asks the user to confirm their marital status by choosing one of 3 options.
            Console.WriteLine("Please confirm the following:");
            Console.WriteLine("1 for single or widowed");
            Console.WriteLine("2 for married");
            Console.WriteLine("3 for married and two incomes");

            int maritalStatus = int.Parse(Console.ReadLine());

//This code then takes the users answer and calls the relevant method to calculate their income tax.
            if(maritalStatus == 1)
            {
                Console.WriteLine("If you are widowed, do you have any dependant children?");
                Console.WriteLine("1 for yes");
                Console.WriteLine("2 for no");
                int widowChildren = int.Parse(Console.ReadLine());

                if (widowChildren == 1)
                {
                    grossIncomeTax = singlePersonIncomeChildren(grossIncome);
                }
                else
                {
                    grossIncomeTax = singlePersonIncome(grossIncome);
                }
            }

            if (maritalStatus == 2)
            {
                grossIncomeTax = marriedOneIncome(grossIncome);
            }

            if (maritalStatus == 3)
            {
                grossIncomeTax = marriedTwoIncome(grossIncome);
            }

            Console.WriteLine();

//This code works out if a person on PAYE and subtracts it from the total.

            Console.WriteLine("Are you on PAYE?");
            Console.WriteLine("1 for Yes");
            Console.WriteLine("2 for No");
            int payeAnswer = int.Parse(Console.ReadLine());

            if (payeAnswer == 1)
            {
                grossIncomeTax = payeMethod(grossIncomeTax);
            }

            Console.WriteLine("Your tax after PAYE allowance is:");
            Console.WriteLine(grossIncomeTax);

//This takes away allowance if a person is blind 
            Console.WriteLine("Are you visually impaired?");
            Console.WriteLine("1 for Yes");
            Console.WriteLine("2 for No");
            int blindAnswer = int.Parse(Console.ReadLine());

            if(blindAnswer == 1)
            {
                grossIncomeTax = blindMethod(grossIncomeTax);
                Console.WriteLine("Your tax after blind allowance is:");
                Console.WriteLine(grossIncomeTax);
            }

//This takes away allowance if a person is a home carer
            Console.WriteLine("Are you a home carer?");
            Console.WriteLine("1 for Yes");
            Console.WriteLine("2 for No");
            int homeCarer = int.Parse(Console.ReadLine());

            if (homeCarer == 1)
            {
                grossIncomeTax = carerMethod(grossIncomeTax);
                Console.WriteLine("Your tax after carer allowance is:");
                Console.WriteLine(grossIncomeTax);
            }

            //PRSI Calculation
            double prsiValue = prsiMethod(grossIncome);
            Console.WriteLine("Total PRSI = " + prsiValue);

            //Total of income tax/allowances/PRSI
            double totalTaxDue = grossIncomeTax + prsiValue;
            Console.WriteLine("The total tax liability is: " + totalTaxDue);

            double netIncome = grossIncome - totalTaxDue;
            Console.WriteLine("Your net take home pay is: " + netIncome);

            Console.ReadLine();

//This method calculates income tax for single/widowed individuals.
            static double singlePersonIncome(double grossIncome)
            {
                double singleBand = 36400;
                int singleAllowance = 1830;
                if (grossIncome >= singleBand)
                {
                     Console.WriteLine("You're single and paying at a higher tax rate");
                    double highTaxBalance = grossIncome - singleBand;
                    double incomeTax = (singleBand * 0.2) + (highTaxBalance * 0.41);
                    Console.WriteLine("Your tax before allowance's:");
                    Console.WriteLine(incomeTax);

                    Console.WriteLine("Your allowance for being single/widowed is:" + singleAllowance);
                    Console.WriteLine("Your tax after this allowance is:");
                    incomeTax = (incomeTax - singleAllowance);
                    Console.WriteLine(incomeTax);
                    return incomeTax;
                }
                else
                {
                    Console.WriteLine("You're single and only paying the low rate of tax");
                    double incomeTax = grossIncome * 0.2;
                    Console.WriteLine("Your tax before allowance's:");
                    Console.WriteLine(incomeTax);

                    Console.WriteLine("Your allowance for being widowed with dependant children is:" + singleAllowance);
                    Console.WriteLine("Your tax after this allowance is:");
                    incomeTax = (incomeTax - singleAllowance);
                    Console.WriteLine(incomeTax);
                    return incomeTax;
                }
            }

//This method works out income tax due for widows with dependant children.
            static double singlePersonIncomeChildren(double grossIncome)
            {
                double singleBand = 36400;
                int widowAllowance = 2430;
                if (grossIncome >= singleBand)
                {
                    Console.WriteLine("You're single and paying at a higher tax rate");
                    double highTaxBalance = grossIncome - singleBand;
                    double incomeTax = (singleBand * 0.2) + (highTaxBalance * 0.41);
                    Console.WriteLine("Your tax before allowance's:");
                    Console.WriteLine(incomeTax);

                    Console.WriteLine("Your allowance for being married is:" + widowAllowance);
                    Console.WriteLine("Your tax after this allowance is:");
                    incomeTax = (incomeTax - widowAllowance);
                    Console.WriteLine(incomeTax);
                    return incomeTax;
                }
                else
                {
                    Console.WriteLine("You're single and only paying the low rate of tax");
                    double incomeTax = grossIncome * 0.2;
                    Console.WriteLine("Your tax before allowance's:");
                    Console.WriteLine(incomeTax);

                    Console.WriteLine("Your allowance for being married is:" + widowAllowance);
                    Console.WriteLine("Your tax after this allowance is:");
                    incomeTax = (incomeTax - widowAllowance);
                    Console.WriteLine(incomeTax);
                    return incomeTax;
                }
            }
//This method calculates income tax for a married person with ONE INCOME
            static double marriedOneIncome(double grossIncome)
            {
                int marriedAllowance = 3660;
                double oneIncomeBand = 41400;
                if (grossIncome >= oneIncomeBand)
                {
                    Console.WriteLine("You're married with one income and  paying at a higher tax rate");
                    double highTaxBalance = grossIncome - oneIncomeBand;
                    double incomeTax = (oneIncomeBand * 0.2) + (highTaxBalance * 0.41);
                    Console.WriteLine("Your tax before allowance's:");
                    Console.WriteLine(incomeTax);

                    Console.WriteLine("Your allowance for being married is:" + marriedAllowance);
                    Console.WriteLine("Your tax after this allowance is:");
                    incomeTax = (incomeTax - marriedAllowance);
                    Console.WriteLine(incomeTax);
                    return incomeTax;
                }
                else
                {
                    Console.WriteLine("You're married with ONE income and only paying the low rate of tax");
                    double incomeTax = grossIncome * 0.2;
                    Console.WriteLine("Your tax before allowance's:");
                    Console.WriteLine(incomeTax);

                    Console.WriteLine("Your allowance for being married is:" + marriedAllowance);
                    Console.WriteLine("Your tax after this allowance is:");
                    incomeTax = (incomeTax - marriedAllowance);
                    Console.WriteLine(incomeTax);
                    return incomeTax;
                }
            }

 //This method calculates income tax for a married person with TWO INCOMES.
            static double marriedTwoIncome(double grossIncome)
                {
                int marriedAllowance = 3660;
                    double twoIncomeBand = 45400;
                    if (grossIncome >= twoIncomeBand)
                    {
                    Console.WriteLine("You're married with TWO incomes and paying at a higher tax rate");
                    double highTaxBalance = grossIncome - twoIncomeBand;
                    double incomeTax = (twoIncomeBand * 0.2) + (highTaxBalance * 0.41);
                    Console.WriteLine("Your tax before allowance's:");
                    Console.WriteLine(incomeTax);

                    Console.WriteLine("Your allowance for being married is:" + marriedAllowance);
                    Console.WriteLine("Your tax after this allowance is:");
                    incomeTax = (incomeTax - marriedAllowance);
                    Console.WriteLine(incomeTax);
                    return incomeTax;
                    }
                    else
                    {
                    Console.WriteLine("You're MARRIED WITH TWO INCOMES and only paying the low rate of tax");
                    double incomeTax = grossIncome * 0.2;
                    Console.WriteLine("Your tax before allowance's:");
                    Console.WriteLine(incomeTax);

                    Console.WriteLine("Your allowance for being married is:" + marriedAllowance);
                    Console.WriteLine("Your tax after this allowance is:");
                    incomeTax = (incomeTax - marriedAllowance);
                    Console.WriteLine(incomeTax);
                    return incomeTax;
                    }
            }

//Calculation method for PAYE
            static double payeMethod(double grossIncomeTax)
            {
                int payeCredit = 1830;
                grossIncomeTax = (grossIncomeTax - payeCredit);
                return grossIncomeTax;
            }

//this takes the blind allowance off their tax bill if entitled         
            static double blindMethod(double grossIncomeTax)
            {
                int blindAllowance = 1830;
                Console.WriteLine("You're entitled to " + blindAllowance + " off your tax.");
                grossIncomeTax = grossIncomeTax - blindAllowance;
                return grossIncomeTax;
            }

//this takes the carer allowance off their tax bill if entitled         
            static double carerMethod(double grossIncomeTax)
            {
                int careAllowance = 900;
                Console.WriteLine("You're entitled to " + careAllowance + " off your tax.");
                grossIncomeTax = grossIncomeTax - careAllowance;
                return grossIncomeTax;
            }
            //Method for calculating PRSI
            static double prsiMethod(double grossIncome)
            {

                double prsiHighRate = 0.025;
                double prsiMidRate = 0.02;
                double prsiLowRate = 0.06;

                double highPrsiBand = 100100;
                double midPrsiBand = 50700;

                double lowPrsiAmount = grossIncome * prsiLowRate;
                double midPrsiAmount = (grossIncome - midPrsiBand) * prsiMidRate;
                double highPrsiAmount = (grossIncome - highPrsiBand) * prsiHighRate;

                if (grossIncome >= highPrsiBand)
                {
                    double totalPrsi = ((grossIncome - highPrsiBand) * prsiHighRate) + (49400 * prsiMidRate) + (midPrsiBand * prsiLowRate);
                    return totalPrsi;
                }

                if (grossIncome >= midPrsiBand && grossIncome < highPrsiBand)
                {
                    double middlePrsi = grossIncome - midPrsiBand;
                    double totalPrsi = (middlePrsi * prsiMidRate) + (midPrsiBand * prsiLowRate);
                    return totalPrsi;
                }

                if (grossIncome < midPrsiBand)
                {
                    double totalPrsi = lowPrsiAmount;
                    return totalPrsi;
                }

                return grossIncome;

            }
        }
    }
}
